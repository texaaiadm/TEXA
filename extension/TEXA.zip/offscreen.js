// =============================================
// TEXA Offscreen Document Script
// SILENT Token Scraping menggunakan Browser Google Session
// =============================================

const GOOGLE_LABS_URL = 'https://labs.google/fx/tools/flow';
const GOOGLE_LABS_API_URLS = [
    'https://labs.google/fx/tools/flow',
    'https://labs.google/fx/api/tools',
    'https://labs.google/fx'
];
const TOKEN_REGEX = /ya29\.[a-zA-Z0-9_-]{100,}/g;

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'OFFSCREEN_SCRAPE_TOKEN') {
        console.log('TEXA Offscreen: Starting silent scrape using browser session...');
        scrapeTokenSilently()
            .then(result => sendResponse(result))
            .catch(err => sendResponse({ success: false, error: err.message }));
        return true; // async response
    }

    if (message.type === 'OFFSCREEN_CHECK_LOGIN') {
        console.log('TEXA Offscreen: Checking Google login status...');
        checkGoogleLoginStatus()
            .then(result => sendResponse(result))
            .catch(err => sendResponse({ success: false, error: err.message }));
        return true;
    }
});

// Silent token scraping using browser's Google session cookies
async function scrapeTokenSilently() {
    console.log('TEXA Offscreen: Attempting silent fetch with browser credentials...');

    // Try multiple URLs
    for (const url of GOOGLE_LABS_API_URLS) {
        try {
            const result = await fetchWithBrowserSession(url);
            if (result.success) {
                return result;
            }
        } catch (e) {
            console.log(`TEXA Offscreen: Failed to fetch ${url}:`, e.message);
        }
    }

    // Final attempt with XMLHttpRequest (different credential handling)
    try {
        const xhrResult = await fetchViaXHR(GOOGLE_LABS_URL);
        if (xhrResult.success) {
            return xhrResult;
        }
    } catch (e) {
        console.log('TEXA Offscreen: XHR attempt failed:', e.message);
    }

    return { success: false, error: 'Could not retrieve token from any endpoint' };
}

// Fetch using browser session cookies
async function fetchWithBrowserSession(url) {
    try {
        const response = await fetch(url, {
            method: 'GET',
            credentials: 'include', // Include cookies from browser session
            mode: 'cors',
            headers: {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache'
            },
            cache: 'no-store',
            redirect: 'follow'
        });

        if (!response.ok) {
            return { success: false, error: `HTTP ${response.status}` };
        }

        const html = await response.text();

        // Check for login redirect
        if (html.includes('accounts.google.com') ||
            html.includes('Sign in') ||
            html.includes('identifier') ||
            response.url.includes('accounts.google.com')) {
            console.log('TEXA Offscreen: Detected login redirect - user may not be logged in');
            return { success: false, notLoggedIn: true, error: 'Not logged in to Google' };
        }

        // Search for token
        const matches = html.match(TOKEN_REGEX);

        if (matches && matches.length > 0) {
            // Get longest token (most complete)
            const token = matches.reduce((a, b) => a.length > b.length ? a : b);
            console.log('TEXA Offscreen: Token found! Length:', token.length);

            // Notify background
            chrome.runtime.sendMessage({
                type: 'TEXA_TOKEN_FOUND',
                token: token,
                source: 'Offscreen Silent (Browser Session)'
            });

            return { success: true, token: token, method: 'offscreen_fetch' };
        }

        console.log('TEXA Offscreen: Page fetched but no token found. Page length:', html.length);
        return { success: false, error: 'No token in page content' };

    } catch (error) {
        console.error('TEXA Offscreen: Fetch error:', error);
        return { success: false, error: error.message };
    }
}

// Alternative: Fetch via XMLHttpRequest (different cookie handling)
function fetchViaXHR(url) {
    return new Promise((resolve) => {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.withCredentials = true; // Include cookies

        xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300) {
                const html = xhr.responseText;
                const matches = html.match(TOKEN_REGEX);

                if (matches && matches.length > 0) {
                    const token = matches.reduce((a, b) => a.length > b.length ? a : b);
                    console.log('TEXA Offscreen: Token found via XHR!');

                    chrome.runtime.sendMessage({
                        type: 'TEXA_TOKEN_FOUND',
                        token: token,
                        source: 'Offscreen XHR (Browser Session)'
                    });

                    resolve({ success: true, token: token, method: 'offscreen_xhr' });
                } else {
                    resolve({ success: false, error: 'No token in XHR response' });
                }
            } else {
                resolve({ success: false, error: `XHR status ${xhr.status}` });
            }
        };

        xhr.onerror = () => {
            resolve({ success: false, error: 'XHR network error' });
        };

        xhr.timeout = 15000;
        xhr.ontimeout = () => {
            resolve({ success: false, error: 'XHR timeout' });
        };

        xhr.send();
    });
}

// Check if user is logged in to Google
async function checkGoogleLoginStatus() {
    try {
        // Fetch Google's account list endpoint
        const response = await fetch('https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser', {
            credentials: 'include',
            cache: 'no-store'
        });

        if (response.ok) {
            const text = await response.text();
            // If response contains email patterns, user is logged in
            const hasAccounts = text.includes('@gmail.com') ||
                text.includes('@googlemail.com') ||
                (text.length > 200 && !text.includes('Sign in'));

            console.log('TEXA Offscreen: Login check - logged in:', hasAccounts);
            return { loggedIn: hasAccounts };
        }

        return { loggedIn: false };
    } catch (error) {
        console.error('TEXA Offscreen: Login check error:', error);
        return { loggedIn: false, error: error.message };
    }
}

console.log('TEXA Offscreen Document Loaded (Silent Mode - Uses Browser Google Session)');
