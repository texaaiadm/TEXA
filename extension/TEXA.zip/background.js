// =============================================
// TEXA Tools Manager - Background Service Worker
// SILENT Token Scraping dengan Google Identity
// =============================================

// Firebase REST API Configuration
const FIREBASE_PRIMARY = {
    projectId: 'tekno-cfaba',
    tokenPath: 'artifacts/my-token-vault/public/data/tokens/google_oauth_user_1'
};

const FIREBASE_BACKUP = {
    projectId: 'tekno-335f8',
    rtdbUrl: 'https://tekno-335f8-default-rtdb.asia-southeast1.firebasedatabase.app',
    tokenPath: 'texa_tokens/google_oauth_user_1'
};

const GOOGLE_LABS_URL = 'https://labs.google/fx/tools/flow';
const GOOGLE_LABS_API = 'https://labs.google/fx/api/tools';
const TOKEN_REGEX = /ya29\.[a-zA-Z0-9_-]{100,}/g;

function getFirestoreUrl(projectId, path) {
    return `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/${path}`;
}

function getRtdbUrl(path) {
    return `${FIREBASE_BACKUP.rtdbUrl}/${path}.json`;
}

// =============================================
// OFFSCREEN DOCUMENT MANAGEMENT
// =============================================

let creatingOffscreen = false;

async function hasOffscreenDocument() {
    try {
        const contexts = await chrome.runtime.getContexts({
            contextTypes: ['OFFSCREEN_DOCUMENT']
        });
        return contexts.length > 0;
    } catch (e) {
        return false;
    }
}

async function setupOffscreenDocument() {
    if (await hasOffscreenDocument()) {
        return true;
    }

    if (creatingOffscreen) {
        await new Promise(r => setTimeout(r, 200));
        return await hasOffscreenDocument();
    }

    creatingOffscreen = true;
    try {
        await chrome.offscreen.createDocument({
            url: 'offscreen.html',
            reasons: ['DOM_SCRAPING'],
            justification: 'Silent token extraction using browser Google session'
        });
        console.log('✅ TEXA: Offscreen document created');
        return true;
    } catch (e) {
        console.log('⚠️ TEXA: Offscreen creation:', e.message);
        return false;
    } finally {
        creatingOffscreen = false;
    }
}

async function closeOffscreenDocument() {
    if (await hasOffscreenDocument()) {
        try {
            await chrome.offscreen.closeDocument();
        } catch (e) { }
    }
}

// =============================================
// MAIN SILENT SCRAPE FUNCTION
// =============================================

async function scrapeToken() {
    console.log('🔄 TEXA: Starting SILENT token scrape (using browser Google session)...');

    try {
        // Method 1: Try offscreen document with credentials (most reliable for using browser session)
        const offscreenResult = await scrapeViaOffscreen();
        if (offscreenResult.success) {
            console.log('✅ TEXA: Token found via offscreen document!');
            return offscreenResult;
        }

        // Method 2: Check existing Google Labs tabs (user might have it open)
        const existingResult = await scrapeFromExistingTabs();
        if (existingResult.success) {
            console.log('✅ TEXA: Token found from existing tab!');
            return existingResult;
        }

        // Method 3: Try to get token via Chrome Identity API (uses browser profile)
        const identityResult = await scrapeViaIdentity();
        if (identityResult.success) {
            console.log('✅ TEXA: Token found via Chrome Identity!');
            return identityResult;
        }

        // Method 4: Load from Firebase cache as fallback
        const cachedResult = await getToken();
        if (cachedResult.success) {
            console.log('✅ TEXA: Using cached token from Firebase');
            return cachedResult;
        }

        console.log('⚠️ TEXA: No token found via silent methods');
        return { success: false, error: 'Token not available - please visit labs.google once to initialize' };

    } catch (error) {
        console.error('🔄 TEXA Error:', error);
        return { success: false, error: error.message };
    }
}

// =============================================
// OFFSCREEN DOCUMENT SCRAPE (Uses Browser Cookies)
// =============================================

async function scrapeViaOffscreen() {
    try {
        console.log('🔄 TEXA: Trying offscreen document with browser session...');

        const hasOffscreen = await setupOffscreenDocument();
        if (!hasOffscreen) {
            return { success: false, error: 'Could not create offscreen document' };
        }

        // Wait a bit for offscreen to be ready
        await new Promise(r => setTimeout(r, 300));

        // Send message to offscreen document
        const result = await new Promise((resolve) => {
            const timeout = setTimeout(() => {
                resolve({ success: false, error: 'Offscreen timeout' });
            }, 20000);

            chrome.runtime.sendMessage({ type: 'OFFSCREEN_SCRAPE_TOKEN' }, (response) => {
                clearTimeout(timeout);
                if (chrome.runtime.lastError) {
                    resolve({ success: false, error: chrome.runtime.lastError.message });
                } else {
                    resolve(response || { success: false, error: 'No response from offscreen' });
                }
            });
        });

        if (result.success && result.token) {
            await saveToken(result.token, 'Offscreen (Browser Session)');
        }

        return result;
    } catch (e) {
        console.log('⚠️ TEXA: Offscreen scrape failed:', e.message);
        return { success: false, error: e.message };
    }
}

// =============================================
// CHROME IDENTITY API (Uses Browser Profile's Google Account)
// =============================================

async function scrapeViaIdentity() {
    try {
        console.log('🔄 TEXA: Trying Chrome Identity API...');

        // Get OAuth token using the browser's logged-in Google account
        const token = await new Promise((resolve) => {
            chrome.identity.getAuthToken({
                interactive: false  // Silent, no popup - uses existing login
            }, (authToken) => {
                if (chrome.runtime.lastError) {
                    console.log('⚠️ TEXA: Identity error:', chrome.runtime.lastError.message);
                    resolve(null);
                } else {
                    resolve(authToken);
                }
            });
        });

        if (token) {
            console.log('✅ TEXA: Got token via Chrome Identity');
            await saveToken(token, 'Chrome Identity API');
            return { success: true, token, method: 'chrome_identity' };
        }

        return { success: false, error: 'No identity token available' };
    } catch (e) {
        console.log('⚠️ TEXA: Identity API failed:', e.message);
        return { success: false, error: e.message };
    }
}

// =============================================
// EXISTING TABS SCRAPE
// =============================================

async function scrapeFromExistingTabs() {
    try {
        const labsTabs = await chrome.tabs.query({ url: '*://labs.google/*' });

        for (const tab of labsTabs) {
            if (!tab.url.includes('accounts.google.com')) {
                const result = await extractTokenFromTab(tab.id);
                if (result.success) {
                    return result;
                }
            }
        }

        return { success: false, error: 'No existing Labs tabs with token' };
    } catch (e) {
        return { success: false, error: e.message };
    }
}

async function extractTokenFromTab(tabId) {
    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: () => {
                const regex = /ya29\.[a-zA-Z0-9_-]{100,}/g;
                const html = document.documentElement.outerHTML;
                const matches = html.match(regex);
                if (matches && matches.length > 0) {
                    return matches.reduce((a, b) => a.length > b.length ? a : b);
                }
                return null;
            }
        });

        if (results?.[0]?.result) {
            const token = results[0].result;
            await saveToken(token, 'Existing Tab');
            return { success: true, token, method: 'existing_tab' };
        }
    } catch (e) {
        console.log('⚠️ TEXA: Cannot extract from tab:', e.message);
    }
    return { success: false };
}

// =============================================
// TOKEN STORAGE
// =============================================

async function saveToken(token, source) {
    const timestamp = new Date().toISOString();
    console.log('💾 TEXA: Saving token from:', source);

    // Save to local storage immediately
    await chrome.storage.local.set({
        'texa_bearer_token': token,
        'texa_token_updated': timestamp,
        'texa_token_source': source
    });

    // Save to Firebase (primary + backup) in background
    Promise.allSettled([
        saveToPrimary(token, source, timestamp),
        saveToBackup(token, source, timestamp)
    ]).then(results => {
        console.log('💾 TEXA: Primary:', results[0].status, '| Backup:', results[1].status);
    });

    return true;
}

async function saveToPrimary(token, source, timestamp) {
    const url = getFirestoreUrl(FIREBASE_PRIMARY.projectId, FIREBASE_PRIMARY.tokenPath);
    const response = await fetch(url, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            fields: {
                token: { stringValue: token },
                id: { stringValue: 'google_oauth_user_1' },
                updatedAt: { timestampValue: timestamp },
                source: { stringValue: source }
            }
        })
    });
    if (!response.ok) throw new Error(`Primary error: ${response.status}`);
    return { success: true };
}

async function saveToBackup(token, source, timestamp) {
    const url = getRtdbUrl(FIREBASE_BACKUP.tokenPath);
    const response = await fetch(url, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            token,
            id: 'google_oauth_user_1',
            updatedAt: timestamp,
            source
        })
    });
    if (!response.ok) throw new Error(`Backup error: ${response.status}`);
    return { success: true };
}

async function getToken() {
    // Try local cache first (fastest)
    const cached = await chrome.storage.local.get(['texa_bearer_token', 'texa_token_updated', 'texa_token_source']);
    if (cached.texa_bearer_token) {
        // Check if token is recent (less than 30 minutes old)
        const updatedAt = new Date(cached.texa_token_updated);
        const ageMinutes = (Date.now() - updatedAt.getTime()) / 60000;
        if (ageMinutes < 30) {
            return { success: true, token: cached.texa_bearer_token, source: 'local_cache', updatedAt: cached.texa_token_updated };
        }
    }

    // Try primary Firebase
    try {
        const url = getFirestoreUrl(FIREBASE_PRIMARY.projectId, FIREBASE_PRIMARY.tokenPath);
        const response = await fetch(url);
        if (response.ok) {
            const data = await response.json();
            const token = data.fields?.token?.stringValue;
            if (token) {
                // Update local cache
                await chrome.storage.local.set({
                    'texa_bearer_token': token,
                    'texa_token_updated': data.fields?.updatedAt?.timestampValue,
                    'texa_token_source': 'primary_firebase'
                });
                return { success: true, token, source: 'primary', updatedAt: data.fields?.updatedAt?.timestampValue };
            }
        }
    } catch (e) {
        console.log('⚠️ TEXA: Primary fetch failed');
    }

    // Try backup Firebase
    try {
        const url = getRtdbUrl(FIREBASE_BACKUP.tokenPath);
        const response = await fetch(url);
        if (response.ok) {
            const data = await response.json();
            if (data?.token) {
                // Update local cache
                await chrome.storage.local.set({
                    'texa_bearer_token': data.token,
                    'texa_token_updated': data.updatedAt,
                    'texa_token_source': 'backup_firebase'
                });
                return { success: true, token: data.token, source: 'backup', updatedAt: data.updatedAt };
            }
        }
    } catch (e) {
        console.log('⚠️ TEXA: Backup fetch failed');
    }

    // Return cached token even if old
    if (cached.texa_bearer_token) {
        return { success: true, token: cached.texa_bearer_token, source: 'cache_stale', updatedAt: cached.texa_token_updated };
    }

    return { success: false, error: 'No token found' };
}

// =============================================
// MESSAGE HANDLERS
// =============================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const type = message.type || message.action;
    console.log('📨 TEXA Background:', type);

    switch (type) {
        case 'TEXA_TOKEN_FOUND':
            saveToken(message.token, message.source || 'Content Script');
            sendResponse({ success: true });
            break;

        case 'TEXA_SCRAPE_TOKEN':
            scrapeToken()
                .then(r => sendResponse(r))
                .catch(e => sendResponse({ success: false, error: e.message }));
            return true;

        case 'TEXA_GET_TOKEN':
            getToken()
                .then(r => sendResponse(r))
                .catch(e => sendResponse({ success: false, error: e.message }));
            return true;

        case 'TEXA_OPEN_TOOL':
            handleOpenTool(message)
                .then(r => sendResponse(r))
                .catch(e => sendResponse({ success: false, error: e.message }));
            return true;

        case 'SAVE_TOKEN':
            saveToken(message.payload?.token, message.payload?.service)
                .then(() => sendResponse({ status: 'success' }))
                .catch(e => sendResponse({ status: 'error', msg: e.message }));
            return true;
    }
});

// =============================================
// TOOL OPENING - Supports both direct cookies and API fetch
// =============================================

async function handleOpenTool(data) {
    const { targetUrl, apiUrl, cookiesData, authHeader, idToken } = data;

    console.log('🔧 TEXA: Opening tool:', targetUrl);
    console.log('🔧 TEXA: cookiesData:', cookiesData ? 'Provided' : 'None');
    console.log('🔧 TEXA: apiUrl:', apiUrl || 'None');

    let cookiesInjected = 0;

    // Priority 1: Use direct cookiesData from tool settings (Edit Tools)
    if (cookiesData) {
        try {
            console.log('🍪 TEXA: Injecting cookies from tool settings (cookiesData)...');
            const cookies = parseCookiesData(cookiesData);

            for (const cookie of cookies) {
                try {
                    await setCookie(cookie, targetUrl);
                    cookiesInjected++;
                } catch (e) {
                    console.log('⚠️ TEXA: Failed to set cookie:', cookie.name, e.message);
                }
            }
            console.log(`✅ TEXA: Injected ${cookiesInjected} cookies from cookiesData`);
        } catch (e) {
            console.error('❌ TEXA: Error parsing cookiesData:', e.message);
        }
    }

    // Priority 2: Fetch cookies from API URL (if no cookiesData or as additional source)
    if (apiUrl) {
        try {
            console.log('🌐 TEXA: Fetching cookies from API:', apiUrl);

            const headers = {};
            if (authHeader) {
                headers['Authorization'] = authHeader;
            } else if (idToken) {
                headers['Authorization'] = `Bearer ${idToken}`;
            }

            const response = await fetch(apiUrl, {
                headers: Object.keys(headers).length > 0 ? headers : undefined
            });

            if (response.ok) {
                const apiData = await response.json();
                const cookies = extractCookiesFromAPI(apiData);

                for (const cookie of cookies) {
                    try {
                        await setCookie(cookie, targetUrl);
                        cookiesInjected++;
                    } catch (e) {
                        console.log('⚠️ TEXA: Failed to set API cookie:', cookie.name, e.message);
                    }
                }
                console.log(`✅ TEXA: Injected ${cookies.length} cookies from API`);
            } else {
                console.log('⚠️ TEXA: API response not OK:', response.status);
            }
        } catch (e) {
            console.error('❌ TEXA: Error fetching from API:', e.message);
        }
    }

    console.log(`🎯 TEXA: Total cookies injected: ${cookiesInjected}`);

    // Open the target URL
    await chrome.tabs.create({ url: targetUrl });
    return { success: true, cookiesInjected };
}

// Parse cookiesData string (JSON array) from tool settings
function parseCookiesData(cookiesData) {
    if (!cookiesData) return [];

    try {
        // If it's already an array, return it
        if (Array.isArray(cookiesData)) {
            return cookiesData;
        }

        // If it's a string, try to parse as JSON
        if (typeof cookiesData === 'string') {
            const parsed = JSON.parse(cookiesData);

            // Could be an array or object with cookies property
            if (Array.isArray(parsed)) {
                return parsed;
            }
            if (parsed.cookies && Array.isArray(parsed.cookies)) {
                return parsed.cookies;
            }
        }
    } catch (e) {
        console.error('❌ TEXA: Failed to parse cookiesData:', e.message);
    }

    return [];
}

// Extract cookies from API response (handles various formats)
function extractCookiesFromAPI(data) {
    // Handle Firestore format
    if (data.fields) {
        for (const key in data.fields) {
            if (data.fields[key].stringValue) {
                try {
                    const parsed = JSON.parse(data.fields[key].stringValue);
                    if (Array.isArray(parsed)) return parsed;
                    if (parsed.cookies) return parsed.cookies;
                } catch (e) { }
            }
            // Handle arrayValue format
            if (data.fields[key].arrayValue?.values) {
                return data.fields[key].arrayValue.values.map(v => {
                    if (v.mapValue?.fields) {
                        const fields = v.mapValue.fields;
                        return {
                            name: fields.name?.stringValue,
                            value: fields.value?.stringValue,
                            domain: fields.domain?.stringValue,
                            path: fields.path?.stringValue || '/',
                            secure: fields.secure?.booleanValue,
                            httpOnly: fields.httpOnly?.booleanValue,
                            sameSite: fields.sameSite?.stringValue
                        };
                    }
                    return null;
                }).filter(Boolean);
            }
        }
    }

    // Handle direct array
    if (Array.isArray(data)) {
        return data;
    }

    // Handle object with cookies property
    if (data.cookies && Array.isArray(data.cookies)) {
        return data.cookies;
    }

    return [];
}

function setCookie(c, targetUrl) {
    const domain = c.domain || new URL(targetUrl).hostname;
    const cookieDetails = {
        url: c.url || `https://${domain.replace(/^\./, '')}${c.path || '/'}`,
        name: c.name,
        value: c.value,
        path: c.path || '/',
        secure: c.secure !== false,
        httpOnly: c.httpOnly === true
    };

    // Add optional fields if present
    if (c.domain) cookieDetails.domain = c.domain;
    if (c.expirationDate) cookieDetails.expirationDate = c.expirationDate;
    if (c.sameSite) cookieDetails.sameSite = c.sameSite;

    return chrome.cookies.set(cookieDetails);
}

// =============================================
// LIFECYCLE EVENTS - SILENT AUTO SCRAPING
// =============================================

chrome.runtime.onStartup.addListener(() => {
    console.log('🔄 TEXA: Extension started - initiating silent scrape');
    setTimeout(() => scrapeToken(), 3000);
});

chrome.runtime.onInstalled.addListener(() => {
    console.log('✅ TEXA: Extension installed');
    // Setup periodic silent refresh every 25 minutes
    chrome.alarms.create('tokenRefresh', { periodInMinutes: 25 });
    // Initial silent scrape
    setTimeout(() => scrapeToken(), 5000);
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'tokenRefresh') {
        console.log('⏰ TEXA: Periodic silent token refresh');
        scrapeToken();
    }
});

// Passive scrape when user visits Google Labs manually
chrome.webNavigation.onCompleted.addListener((details) => {
    if (details.url.includes('labs.google') && !details.url.includes('accounts.google.com')) {
        console.log('📍 TEXA: User visited Labs, extracting token silently...');
        setTimeout(() => extractTokenFromTab(details.tabId), 2000);
    }
}, { url: [{ hostContains: 'labs.google' }] });

console.log('🚀 TEXA Tools Manager - Background Loaded (SILENT MODE with Browser Google Session)');
